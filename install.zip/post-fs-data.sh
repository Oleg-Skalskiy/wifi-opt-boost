#!/system/bin/sh

# Post Fs controller script

mount -o bind $MODPATH/system/vendor/odm/etc/wifi/ $ORIGDIR/odm/etc/wifi/
mount -o bind $MODPATH/system/vendor/odm/vendor/etc/wifi/ $ORIGDIR/odm/vendor/etc/wifi/

mount -o bind $MODPATH/system/my_product/vendor/etc/wifi/ $ORIGDIR/my_product/vendor/etc/wifi/
mount -o bind $MODPATH/system/my_product/etc/wifi/ $ORIGDIR/my_product/etc/wifi/
