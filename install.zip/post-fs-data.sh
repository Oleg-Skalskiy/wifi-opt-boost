# Post Fs controller script

mount -o bind $MODPATH/system/vendor/odm/etc/wifi/ /odm/vendor/etc/wifi/

mount -o bind $MODPATH/system/my_product/vendor/etc/wifi/ /my_product/vendor/etc/wifi/
mount -o bind $MODPATH/system/my_product/etc/wifi/ /my_product/etc/wifi/
