#!/system/bin/sh

# Service controller script

settings put system wifi_assistant 1
settings put system wifi_channel_utilization 0
