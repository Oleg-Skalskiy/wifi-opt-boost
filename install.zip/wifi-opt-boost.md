### WiFi Boost&Opt v1.6 - 01.07.2024

* Improved Wi-Fi stability Fixed
		* Connection errors fixed
		* Fixed high power consumption
		* Fix bootloop
		* Fix old devices
		* Fix HotSpot
		* Add New Parametrs for Speed & Stability
		* Added VOWIFI settings
		* Added log disable settings
		* Enable WMM without QOS
		* Improved speed
		* LDPC, SMPS, MCC is disabled
		* Fix DFS
		* Fix Error
* General
		* Fix Code
		* Fix Some Error
		* Fix Stability System
		* Minor edits
		* Updated base module file MMT (Thanks Zackptg5)

