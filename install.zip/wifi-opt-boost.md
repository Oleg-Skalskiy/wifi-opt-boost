### WiFi Boost&Opt v1.3 - 09.09.2022

* Improved Wi-Fi stability Fixed
  * Connection errors fixed
  * Fixed twt
  * Fixed high power consumption
  * Fix bootloop
  * Fix VHT
  * Minor fixes
