### WiFi Boost&Opt v1.5 - 29.09.2023

* Improved Wi-Fi stability Fixed
  * Connection errors fixed
  * Fixed high power consumption
  * Fix bootloop
  * Fix old devices
  * Fix HotSpot
  * Add New Parametrs for Speed & Stability
  * Fix Error

