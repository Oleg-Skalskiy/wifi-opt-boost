### WiFi Boost&Opt v1.2 - 23.03.2022

* Improved Wi-Fi stability Fixed
  * Connection errors fixed
  * Fixed strong channel offset
  * DFS Unset (Global)
  * Fixed high power consumption
  * Fix bootloop
  * Minor fixes

