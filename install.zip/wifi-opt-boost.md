### WiFi Boost&Opt v1.3 - 12.09.2022

* Improved Wi-Fi stability Fixed
  * Connection errors fixed
  * Fixed high power consumption
  * Fix bootloop
  * Fix VHT
  * Fix DTIM
  * NUD Tracking OFF
  * Enable P2PGO mode
  * Enable adaptive dwell mode
  * Disable twt responder
  * Disable Roam data rssi threshold triggers
  * Minor fixes
