

umount $MODPATH/system/vendor/odm/etc/wifi/
umount $MODPATH/system/vendor/odm/vendor/etc/wifi/

umount $MODPATH/system/my_product/etc/wifi/
umount $MODPATH/system/my_product/vendor/etc/wifi/

WIFICFG="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "WCNSS_qcom_cfg*.ini")"
WIFICFG3="$(find /system /vendor /system_ext /product /odm /my_product /mi_ext -type f -name "icm*.conf")"
mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

cp_ch -r /odm/etc/wifi/ $MODPATH/system/vendor/odm/etc/wifi/
cp_ch -r /odm/vendor/etc/wifi/ $MODPATH/system/vendor/odm/vendor/etc/wifi/
cp_ch -r /my_product/vendor/etc/wifi/ $MODPATH/system/my_product/vendor/etc/wifi/
cp_ch -r /my_product/etc/wifi/ $MODPATH/system/my_product/etc/wifi/

if $KSU || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "delta" ] || [ "$(echo $MAGISK_VER | awk -F- '{ print $NF}')" == "kitsune" ]; then
rm -rf $MODPATH/post-fs-data.sh
rm -rf $MODPATH/system/my_product
rm -rf $MODPATH/system/vendor/odm
fi

	settings put system wifi_assistant 1
	settings put system wifi_channel_utilization 0


ui_print "*               ->[!Please Wait!]<-               *"
ui_print "***************************************************"
ui_print "***************************************************"
ui_print " "

  for OCFG in ${WIFICFG}; do
	CFG="$MODPATH$(echo $OCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OCFG $CFG
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG
	sed -i '/gEnableMemoryDebug/d;s/^END$/gEnableMemoryDebug=0\nEND/g' $CFG
	sed -i '/gEnableFatalEvent/d;s/^END$/gEnableFatalEvent=0\nEND/g' $CFG
	sed -i '/gEnablefwlog/d;s/^END$/gEnablefwlog=0\nEND/g' $CFG
	sed -i '/wlanLoggingEnable/d;s/^END$/wlanLoggingEnable=0\nEND/g' $CFG
	sed -i '/wlanLoggingFEToConsole/d;s/^END$/wlanLoggingFEToConsole=0\nEND/g' $CFG
	sed -i '/gEnableDebugLog/d;s/^END$/gEnableDebugLog=0\nEND/g' $CFG
	sed -i '/gFwDebugLogType/d;s/^END$/gFwDebugLogType=0\nEND/g' $CFG
	sed -i '/gFwDebugLogLevel/d;s/^END$/gFwDebugLogLevel=0\nEND/g' $CFG
	sed -i '/gbug_report_for_scan_results/d;s/^END$/gbug_report_for_scan_results=0\nEND/g' $CFG
	sed -i '/gEnablePacketLog/d;s/^END$/gEnablePacketLog=0\nEND/g' $CFG
	sed -i '/gMulticastHostFwMsgs/d;s/^END$/gMulticastHostFwMsgs=0\nEND/g' $CFG
	sed -i '/gEnableLogp/d;s/^END$/gEnableLogp=0\nEND/g' $CFG
	sed -i '/gEnableHtSMPS/d;s/^END$/gEnableHtSMPS=1\nEND/g' $CFG
	sed -i '/WmmIsEnabled/d;s/^END$/WmmIsEnabled=2\nEND/g' $CFG
	sed -i '/80211eIsEnabled/d;s/^END$/80211eIsEnabled=0\nEND/g' $CFG
	sed -i '/ImplicitQosIsEnabled/d;s/^END$/ImplicitQosIsEnabled=0\nEND/g' $CFG
	sed -i '/bImplicitQosEnabled/d;s/^END$/bImplicitQosEnabled=0\nEND/g' $CFG
	sed -i '/PktClassificationBasis/d;s/^END$/PktClassificationBasis=0\nEND/g' $CFG
	sed -i '/burstSizeDefinition/d;s/^END$/burstSizeDefinition=0\nEND/g' $CFG
	sed -i '/gEnableEdcaParams/d;s/^END$/gEnableEdcaParams=0\nEND/g' $CFG
	sed -i '/gEdca/d' $CFG
	sed -i '/gEnableApUapsd/d;s/^END$/gEnableApUapsd=0\nEND/g' $CFG
	sed -i '/Infra/d' $CFG
	sed -i '/gEnablePowerSaveOffload/d;s/^END$/gEnablePowerSaveOffload=0\nEND/g' $CFG
	sed -i '/gActiveModeOffload/d;s/^END$/gActiveModeOffload=1\nEND/g' $CFG
	sed -i '/gRoamOffloadEnabled/d;s/^END$/gRoamOffloadEnabled=1\nEND/g' $CFG
	sed -i '/enable_dual_sta_roam_offload/d;s/^END$/enable_dual_sta_roam_offload=1\nEND/g' $CFG
	sed -i '/TxPower2g/d' $CFG
	sed -i '/TxPower5g/d' $CFG
	sed -i '/gTxPowerCap/d' $CFG
	sed -i '/gEnable5gEBT/d;s/^END$/gEnable5gEBT=1\nEND/g' $CFG
	sed -i '/gEnableGreenAp/d;s/^END$/gEnableGreenAp=0\nEND/g' $CFG
	sed -i '/gEnableEGAP/d;s/^END$/gEnableEGAP=0\nEND/g' $CFG
	sed -i '/gEnableMemDeepSleep/d;s/^END$/gEnableMemDeepSleep=1\nEND/g' $CFG
	sed -i '/gIbssAwakeOnTxRx/d;s/^END$/gIbssAwakeOnTxRx=1\nEND/g' $CFG
	sed -i '/gEnableDFSMasterCap/d;s/^END$/gEnableDFSMasterCap=0\nEND/g' $CFG
	sed -i '/gEnableSAPDfsChSifsBurst/d;s/^END$/gEnableSAPDfsChSifsBurst=0\nEND/g' $CFG
	sed -i '/gEnableDFSChnlScan/d;s/^END$/gEnableDFSChnlScan=1\nEND/g' $CFG
	sed -i '/gEnableDFSPnoChnlScan/d;s/^END$/gEnableDFSPnoChnlScan=0\nEND/g' $CFG
	sed -i '/gAllowDFSChannelRoam/d;s/^END$/gAllowDFSChannelRoam=0\nEND/g' $CFG
	sed -i '/gDisableDFSChSwitch/d;s/^END$/gDisableDFSChSwitch=1\nEND/g' $CFG
	sed -i '/gDisableDfsJapanW53/d;s/^END$/gDisableDfsJapanW53=1\nEND/g' $CFG
	sed -i '/dfsPhyerrFilterOffload/d;s/^END$/dfsPhyerrFilterOffload=0\nEND/g' $CFG
	sed -i '/gSkipDfsChannelInP2pSearch/d;s/^END$/gSkipDfsChannelInP2pSearch=1\nEND/g' $CFG
	sed -i '/gPreferNonDfsChanOnRadar/d;s/^END$/gPreferNonDfsChanOnRadar=1\nEND/g' $CFG
	sed -i '/gInitialScanNoDFSChnl/d;s/^END$/gInitialScanNoDFSChnl=1\nEND/g' $CFG
	sed -i '/g11hSupportEnabled/d;s/^END$/g11hSupportEnabled=0\nEND/g' $CFG
	sed -i '/gCountryCodePriority/d;s/^END$/gCountryCodePriority=1\nEND/g' $CFG
	sed -i '/gEnableStrictRegulatoryForFCC/d;s/^END$/gEnableStrictRegulatoryForFCC=0\nEND/g' $CFG
	sed -i '/gRegulatoryChangeCountry/d;s/^END$/gRegulatoryChangeCountry=1\nEND/g' $CFG
	sed -i '/gEnforceCountryCodeMatch/d;s/^END$/gEnforceCountryCodeMatch=0\nEND/g' $CFG
	sed -i '/gEnforceDefaultDomain/d;s/^END$/gEnforceDefaultDomain=0\nEND/g' $CFG
	sed -i '/gAPCntryCode/d;s/^END$/gAPCntryCode=FFF\nEND/g' $CFG
	sed -i '/gListOfNonDfsCountryCode/d;s/^END$/gListOfNonDfsCountryCode=ALL\nEND/g' $CFG
	sed -i '/gEnableMuBformee/d;s/^END$/gEnableMuBformee=1\nEND/g' $CFG
	sed -i '/gActiveUcBpfMode/d;s/^END$/gActiveUcBpfMode=0\nEND/g' $CFG
	sed -i '/gActiveMcBcBpfMode/d;s/^END$/gActiveMcBcBpfMode=0\nEND/g' $CFG
	sed -i '/gDisablePacketFilter/d;s/^END$/gDisablePacketFilter=1\nEND/g' $CFG
	sed -i '/McastBcastFilter/d;s/^END$/McastBcastFilter=3\nEND/g' $CFG
	sed -i '/gTxBFEnable/d;s/^END$/gTxBFEnable=1\nEND/g' $CFG
	sed -i '/gEnableTxSUBeamformer/d;s/^END$/gEnableTxSUBeamformer=1\nEND/g' $CFG
	sed -i '/gEnableTxBFeeSAP/d;s/^END$/gEnableTxBFeeSAP=1\nEND/g' $CFG
	sed -i '/gEnableTxBFin20MHz/d;s/^END$/gEnableTxBFin20MHz=1\nEND/g' $CFG
	sed -i '/gEnableTxBFin40MHz/d;s/^END$/gEnableTxBFin20MHz=1\nEND/g' $CFG
	sed -i '/gShortGI20Mhz/d;s/^END$/gShortGI20Mhz=1\nEND/g' $CFG
	sed -i '/gShortGI40Mhz/d;s/^END$/gShortGI40Mhz=1\nEND/g' $CFG
	sed -i '/gEnableWoW/d;s/^END$/gEnableWoW=3\nEND/g' $CFG
	sed -i '/wow_check_rx_pending_enable/d;s/^END$/wow_check_rx_pending_enable=1\nEND/g' $CFG
	sed -i '/wow_check_tx_pending_enable/d;s/^END$/wow_check_tx_pending_enable=1\nEND/g' $CFG
	sed -i '/gwow_pulse_support/d;s/^END$/gwow_pulse_support=1\nEND/g' $CFG
	sed -i '/gExtWoWgotoSuspend/d;s/^END$/gExtWoWgotoSuspend=1\nEND/g' $CFG
	sed -i '/gRoamIntraBand/d;s/^END$/gRoamIntraBand=1\nEND/g' $CFG
	sed -i '/gEnableOverLapCh/d;s/^END$/gEnableOverLapCh=1\nEND/g' $CFG
	sed -i '/gDefaultRateIndex24Ghz/d;s/^END$/gDefaultRateIndex24Ghz=9\nEND/g' $CFG
	sed -i '/gChannelBondingMode24GHz/d;s/^END$/gChannelBondingMode24GHz=10\nEND/g' $CFG
	sed -i '/gChannelBondingMode5GHz/d;s/^END$/gChannelBondingMode5GHz=10\nEND/g' $CFG
	sed -i '/gEnableVhtFor24GHzBand/d;s/^END$/gEnableVhtFor24GHzBand=1\nEND/g' $CFG
	sed -i '/gEnableVhtFor5GHzBand/d;s/^END$/gEnableVhtFor5GHzBand=1\nEND/g' $CFG
	sed -i '/gVhtChannelWidth/d;s/^END$/gVhtChannelWidth=2\nEND/g' $CFG
	sed -i '/oem_6g_support_disable/d;s/^END$/oem_6g_support_disable=0\nEND/g' $CFG
	sed -i '/gSelect5GHzMargin/d;s/^END$/gSelect5GHzMargin=1\nEND/g' $CFG
	sed -i '/g11dSupportEnabled/d;s/^END$/g11dSupportEnabled=0\nEND/g' $CFG
	sed -i '/gEnforce11dChannel/d;s/^END$/gEnforce11dChannel=0\nEND/g' $CFG
	sed -i '/gEnableBypass11d/d;s/^END$/gEnableBypass11d=1\nEND/g' $CFG
	sed -i '/gEnableSARV1toSARV2/d;s/^END$/gEnableSARV1toSARV2=0\nEND/g' $CFG
	sed -i '/CcxEnabled/d;s/^END$/CcxEnabled=1\nEND/g' $CFG
	sed -i '/EseEnabled/d;s/^END$/EseEnabled=1\nEND/g' $CFG
	sed -i '/gEnableNanSupport/d;s/^END$/gEnableNanSupport=1\nEND/g' $CFG
	sed -i '/genable_nan_datapath/d;s/^END$/genable_nan_datapath=1\nEND/g' $CFG
	sed -i '/nan_separate_iface_support/d;s/^END$/nan_separate_iface_support=1\nEND/g' $CFG
	sed -i '/gEnableNDIMacRandomization/d;s/^END$/gEnableNDIMacRandomization=1\nEND/g' $CFG
	sed -i '/gSupportMp0Discovery/d;s/^END$/gSupportMp0Discovery=1\nEND/g' $CFG
	sed -i '/gWmiCreditCount/d;s/^END$/gWmiCreditCount=0\nEND/g' $CFG
	sed -i '/gEnableFastPath/d;s/^END$/gEnableFastPath=1\nEND/g' $CFG
	sed -i '/gEnableMCCMode/d;s/^END$/gEnableMCCMode=0\nEND/g' $CFG
	sed -i '/gEnableTXSTBC/d;s/^END$/gEnableTXSTBC=1\nEND/g' $CFG
	sed -i '/gEnableRXSTBC/d;s/^END$/gEnableRXSTBC=1\nEND/g' $CFG
	sed -i '/gEnableRXLDPC/d;s/^END$/gEnableRXLDPC=0\nEND/g' $CFG
	sed -i '/gEnableTXLDPC/d;s/^END$/gEnableTXLDPC=0\nEND/g' $CFG
	sed -i '/gTxLdpcEnable/d;s/^END$/gTxLdpcEnable=0\nEND/g' $CFG
	sed -i '/gRxLdpcEnable/d;s/^END$/gRxLdpcEnable=0\nEND/g' $CFG
	sed -i '/gDisableLDPCWithTxbfAP/d;s/^END$/gDisableLDPCWithTxbfAP=1\nEND/g' $CFG
	sed -i '/gDisableLDPCWithRxbfAP/d;s/^END$/gDisableLDPCWithRxbfAP=1\nEND/g' $CFG
	sed -i '/gWlanMccToSccSwitchMode/d;s/^END$/gWlanMccToSccSwitchMode=1\nEND/g' $CFG
	sed -i '/gFWMccRtsCtsProtection/d;s/^END$/gFWMccRtsCtsProtection=0\nEND/g' $CFG
	sed -i '/gFWMccBCastProbeResponse/d;s/^END$/gFWMccBCastProbeResponse=0\nEND/g' $CFG
	sed -i '/gEnableMCCAdaptiveScheduler/d;s/^END$/gEnableMCCAdaptiveScheduler=0\nEND/g' $CFG
	sed -i '/gSapChannelAvoidance/d;s/^END$/gSapChannelAvoidance=0\nEND/g' $CFG
	sed -i '/gAllowMCCGODiffBI/d;s/^END$/gAllowMCCGODiffBI = 4\nEND/g' $CFG
	sed -i '/gGO11ACOverride/d;s/^END$/gGO11ACOverride=1\nEND/g' $CFG
	sed -i '/enable_vhtmcs_10_11_support/d;s/^END$/enable_vhtmcs_10_11_support=1\nEND/g' $CFG
	sed -i '/roam_bad_rssi_thresh_offset_2g/d' $CFG
	sed -i '/roam_bg_scan_bad_rssi_thresh/d' $CFG
	sed -i '/ssdp/d;s/^END$/ssdp=1\nEND/g' $CFG
	sed -i '/gEnableSNRMonitoring/d;s/^END$/gEnableSNRMonitoring=0\nEND/g' $CFG
	sed -i '/gEnableTDLSSupport/d;s/^END$/gEnableTDLSSupport=1\nEND/g' $CFG
	sed -i '/gEnableTDLSImplicitTrigger/d;s/^END$/gEnableTDLSImplicitTrigger=1\nEND/g' $CFG
	sed -i '/gTDLSExternalControl/d;s/^END$/gTDLSExternalControl=1\nEND/g' $CFG
	sed -i '/gEnableTDLSBufferSta/d;s/^END$/gEnableTDLSBufferSta=1\nEND/g' $CFG
	sed -i '/gEnableTDLSScan/d;s/^END$/gEnableTDLSScan=1\nEND/g' $CFG
	sed -i '/gEnableTDLSWmmMode/d;s/^END$/gEnableTDLSWmmMode=1\nEND/g' $CFG
	sed -i '/adaptive_dwell_mode_enabled/d;s/^END$/adaptive_dwell_mode_enabled=0\nEND/g' $CFG
	sed -i '/hostscan_adaptive_dwell_mode/d;s/^END$/hostscan_adaptive_dwell_mode=0\nEND/g' $CFG
	sed -i '/gEnableNUDTracking/d' $CFG
	sed -i '/GROEnable/d;s/^END$/GROEnable=1\nEND/g' $CFG
	sed -i '/bcast_twt/d;s/^END$/bcast_twt=0\nEND/g' $CFG
	sed -i '/twt_responder/d;s/^END$/twt_responder=0\nEND/g' $CFG
	sed -i '/gIgnoreDtim/d;s/^END$/gIgnoreDtim=1\nEND/g' $CFG
	sed -i '/gEnableModulatedDTIM/d;s/^END$/gEnableModulatedDTIM=0\nEND/g' $CFG
	sed -i '/gEnableDynamicDTIM/d;s/^END$/gEnableDynamicDTIM=0\nEND/g' $CFG
	sed -i '/gMaxLIModulatedDTIM/d;s/^END$/gMaxLIModulatedDTIM=0\nEND/g' $CFG
	sed -i '/gTelescopicBeaconWakeupEn/d;s/^END$/gTelescopicBeaconWakeupEn=0\nEND/g' $CFG
	sed -i '/gIgnoreDynamicDtimInP2pMode/d;s/^END$/gIgnoreDynamicDtimInP2pMode=1\nEND/g' $CFG
	sed -i '/enable_mod_dtim_on_system_suspend/d;s/^END$/enable_mod_dtim_on_system_suspend=0\nEND/g' $CFG
	sed -i '/irq_affine_audio_use_case/d;s/^END$/irq_affine_audio_use_case=1\nEND/g' $CFG
	sed -i '/wlm_latency_enable/d;s/^END$/wlm_latency_enable=0\nEND/g' $CFG
	sed -i '/wlm_latency_flags_ultralow/d;s/^END$/wlm_latency_flags_ultralow=0\nEND/g' $CFG
	sed -i '/mlo_support_link_num/d;s/^END$/mlo_support_link_num=2\nEND/g' $CFG
	sed -i '/gWESModeEnabled/d;s/^END$/gWESModeEnabled=1\nEND/g' $CFG
	sed -i '/gSapAllowAllChannel/d;s/^END$/gSapAllowAllChannel=1\nEND/g' $CFG
	sed -i '/tx_pkt_inspect_for_ilp/d;s/^END$/tx_pkt_inspect_for_ilp=0\nEND/g' $CFG
	sed -i '/MAWCEnabled/d;s/^END$/MAWCEnabled=0\nEND/g' $CFG
	sed -i '/mawc_roam_enabled/d;s/^END$/mawc_roam_enabled=0\nEND/g' $CFG
	sed -i '/mawc_nlo_enabled/d;s/^END$/mawc_nlo_enabled=0\nEND/g' $CFG
	sed -i '/gEnableBtAmp/d;s/^END$/gEnableBtAmp=1\nEND/g' $CFG
	sed -i '/BtAmpPreferredChannel/d;s/^END$/BtAmpPreferredChannel=0\nEND/g' $CFG
	sed -i '/EnableBeaconEarlyTermination/d;s/^END$/EnableBeaconEarlyTermination=1\nEND/g' $CFG
	sed -i '/gAthDisable/d;s/^END$/gAthDisable=0\nEND/g' $CFG
	#VOWIFI Start
	sed -i '/gRoamPrefer5GHz/d;s/^END$/gRoamPrefer5GHz=1\nEND/g' $CFG
	sed -i '/OkcEnabled/d;s/^END$/OkcEnabled=1\nEND/g' $CFG
	sed -i '/FastTransitionEnabled/d;s/^END$/FastTransitionEnabled=1\nEND/g' $CFG
	sed -i '/gFTResourceReqSupported/d;s/^END$/gFTResourceReqSupported=1\nEND/g' $CFG
	#VOWIFI END
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

  for OCFG3 in ${WIFICFG3}; do
	CFG3="$MODPATH$(echo $OCFG3 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g" | sed "s|^/mi_ext|/system/mi_ext|g")"
	cp_ch $ORIGDIR$OCFG3 $CFG3
	sed -i 's/\t/  /g' $CFG3
	sed -i 's/<<!--.*-->>//; s/<!--.*-->>//; s/<<!--.*-->//; s/<!--.*-->//; /<!--/,/-->/d' $CFG3
	sed -i 's/debug_level=1/debug_level=0/g' $CFG3
	sed -i 's/debug_level=2/debug_level=0/g' $CFG3
	sed -i 's/debug_level=3/debug_level=0/g' $CFG3
	sed -i 's/debug_level=4/debug_level=0/g' $CFG3
	sed -i 's/debug_level=5/debug_level=0/g' $CFG3
	sed -i 's/channel_width=0/channel_width=3/g' $CFG3
	sed -i 's/channel_width=1/channel_width=3/g' $CFG3
	sed -i 's/channel_width=2/channel_width=3/g' $CFG3
	sed -i '/^ *#/d; /^ *$/d' $CFG3
	done

	rm -rf $MODPATH/tools
	rm -rf /data/system/package_cache/*/*
	rm -rf /data/resource-cache/*
	rm -rf /cache/*
	rm -rf /data/local/traces
	rm -rf /data/*/*battery*
	rm -rf /data/*/*charge*
	rm -rf /data/*/bsplog
	rm -rf /data/anr
	rm -rf /data/tombstones
	rm -rf /data/*/tombstones
	find $MODPATH -empty -type d -delete
