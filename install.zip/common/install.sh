
WIFICFG="$(find /system /vendor /system_ext /product /odm -type f -name "WCNSS_qcom_cfg*.ini")"
WIFICFG2="$(find /system /vendor /system_ext /product /odm -type f -name "xtwifi.conf")"
WIFICFG3="$(find /system /vendor /system_ext /product /odm -type f -name "icm.conf")"
mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

ui_print "- Please Wait... -"
  for OCFG in ${WIFICFG}; do
	CFG="$MODPATH$(echo $OCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG $CFG
	sed -i 's/\t/  /g' $CFG
	sed -i '/gEnablefwlog=/d;s/^END$/gEnablefwlog=0\nEND/g' $CFG
	sed -i '/gEnablePacketLog=/d;s/^END$/gEnablePacketLog=0\nEND/g' $CFG
	sed -i '/gMulticastHostFwMsgs=/d;s/^END$/gMulticastHostFwMsgs=0\nEND/g' $CFG
	sed -i '/gEnableApProt=/d;s/^END$/gEnableApProt=0\nEND/g' $CFG
	sed -i '/gEnableApUapsd=/d;s/^END$/gEnableApUapsd=0\nEND/g' $CFG
	sed -i '/InfraUapsdVoSrvIntv=/d;s/^END$/InfraUapsdVoSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdViSrvIntv=/d;s/^END$/InfraUapsdViSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdBeSrvIntv=/d;s/^END$/InfraUapsdBeSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdBkSrvIntv=/d;s/^END$/InfraUapsdBkSrvIntv=0\nEND/g' $CFG
	sed -i '/gEnablePowerSaveOffload=/d;s/^END$/gEnablePowerSaveOffload=0\nEND/g' $CFG
	sed -i '/TxPower2g=/d;s/^END$/#TxPower2g=0\nEND/g' $CFG
	sed -i '/TxPower5g=/d;s/^END$/#TxPower5g=0\nEND/g' $CFG
	sed -i '/gActiveMcBcBpfMode=/d;s/^END$/gActiveMcBcBpfMode=0\nEND/g' $CFG
	sed -i '/gEnableGreenAp=/d;s/^END$/gEnableGreenAp=0\nEND/g' $CFG
	sed -i '/gEnableEGAP=/d;s/^END$/gEnableEGAP=0\nEND/g' $CFG
	sed -i '/g_sta_sap_scc_on_dfs_chan=/d;s/^END$/g_sta_sap_scc_on_dfs_chan=0\nEND/g' $CFG
	sed -i '/gAllowDFSChannelRoam=/d;s/^END$/gAllowDFSChannelRoam=0\nEND/g' $CFG
	sed -i '/gEnableDFSMasterCap=/d;s/^END$/gEnableDFSMasterCap=0\nEND/g' $CFG
	sed -i '/gDFSradarMappingPriMultiplier=/d;s/^END$/gDFSradarMappingPriMultiplier=0\nEND/g' $CFG
	sed -i '/g11hSupportEnabled=/d;s/^END$/g11hSupportEnabled=0\nEND/g' $CFG
	sed -i '/gCountryCodePriority=/d;s/^END$/gCountryCodePriority=0\nEND/g' $CFG
	sed -i '/gEnableMuBformee=/d;s/^END$/gEnableMuBformee=1\nEND/g' $CFG
	sed -i '/gTxBFEnable=/d;s/^END$/gTxBFEnable=1\nEND/g' $CFG
	sed -i '/gEnableTxSUBeamformer=/d;s/^END$/gEnableTxSUBeamformer=1\nEND/g' $CFG
	sed -i '/gEnableTxBFeeSAP=/d;s/^END$/gEnableTxBFeeSAP=1\nEND/g' $CFG
	sed -i '/gEnableTxBFin20MHz=/d;s/^END$/gEnableTxBFin20MHz=1\nEND/g' $CFG
	sed -i '/gShortGI20Mhz=/d;s/^END$/gShortGI20Mhz=1\nEND/g' $CFG
	sed -i '/gShortGI40Mhz=/d;s/^END$/gShortGI40Mhz=1\nEND/g' $CFG
	sed -i '/gChannelBondingMode24GHz=/d;s/^END$/gChannelBondingMode24GHz=1\nEND/g' $CFG
	sed -i '/gChannelBondingMode5GHz=/d;s/^END$/gChannelBondingMode5GHz=1\nEND/g' $CFG
	sed -i '/gEnableVhtFor24GHzBand=/d;s/^END$/gEnableVhtFor24GHzBand=1\nEND/g' $CFG
	sed -i '/gEnableVhtFor50GHzBand=/d;s/^END$/gEnableVhtFor50GHzBand=1\nEND/g' $CFG
	sed -i '/gDot11Mode=/d;s/^END$/gDot11Mode=0\nEND/g' $CFG
	sed -i '/oem_6g_support_disable=/d;s/^END$/oem_6g_support_disable=0\nEND/g' $CFG
	sed -i '/g11dSupportEnabled=/d;s/^END$/g11dSupportEnabled=0\nEND/g' $CFG
	sed -i '/gEnableBypass11d=/d;s/^END$/gEnableBypass11d=1\nEND/g' $CFG
	sed -i '/gEnableSWLM=/d;s/^END$/gEnableSWLM=1\nEND/g' $CFG
	sed -i '/gEnableSARV1toSARV2=/d;s/^END$/#gEnableSARV1toSARV2=1\nEND/g' $CFG
	sed -i '/skip_tpe_consideration=/d;s/^END$/skip_tpe_consideration=1\nEND/g' $CFG
	sed -i '/CcxEnabled=/d;s/^END$/CcxEnabled=1\nEND/g' $CFG
	sed -i '/gEnableNUDTracking=/d;s/^END$/gEnableNUDTracking=0\nEND/g' $CFG
	sed -i '/gEnableNanSupport=/d;s/^END$/gEnableNanSupport=1\nEND/g' $CFG
	sed -i '/genable_nan_datapath=/d;s/^END$/genable_nan_datapath=1\nEND/g' $CFG
	sed -i '/nan_separate_iface_support=/d;s/^END$/nan_separate_iface_support=1\nEND/g' $CFG
	sed -i '/gWmiCreditCount=/d;s/^END$/gWmiCreditCount=0\nEND/g' $CFG
	sed -i '/gEnableFastRoamInConcurrency=/d;s/^END$/gEnableFastRoamInConcurrency=1\nEND/g' $CFG
	sed -i '/ImplicitQosIsEnabled=/d;s/^END$/ImplicitQosIsEnabled=0\nEND/g' $CFG
	sed -i '/gReorderOffloadSupported=/d;s/^END$/gReorderOffloadSupported=1\nEND/g' $CFG
	sed -i '/gEnableIpTcpUdpChecksumOffload=/d;s/^END$/gEnableIpTcpUdpChecksumOffload=1\nEND/g' $CFG
	sed -i '/gEnableFastPath=/d;s/^END$/gEnableFastPath=1\nEND/g' $CFG
	sed -i '/gEnableTXSTBC=/d;s/^END$/gEnableTXSTBC=1\nEND/g' $CFG
	sed -i '/gEnableRXSTBC=/d;s/^END$/gEnableRXSTBC=1\nEND/g' $CFG
	done

  for OCFG2 in ${WIFICFG2}; do
	CFG2="$MODPATH$(echo $OCFG2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG2 $CFG2
	sed -i 's/\t/  /g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 1/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 2/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 3/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 4/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 5/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = ALL/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	done

  for OCFG3 in ${WIFICFG3}; do
	CFG3="$MODPATH$(echo $OCFG3 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG3 $CFG3
	sed -i 's/\t/  /g' $CFG3
	sed -i 's/debug_level=1/debug_level=0/g' $CFG3
	sed -i 's/debug_level=2/debug_level=0/g' $CFG3
	sed -i 's/debug_level=3/debug_level=0/g' $CFG3
	sed -i 's/debug_level=4/debug_level=0/g' $CFG3
	sed -i 's/debug_level=5/debug_level=0/g' $CFG3
	done

	rm -rf /data/system/*_cache/*
	rm -rf /data/vendor/*_cache/*
	rm -rf /data/misc/*_cache/*
	rm -rf /data/*-cache/*
	rm -rf /data/data/com.miui.yellowpage/*
	rm -rf /data/data/com.google.android.gms/app_dg_cache/*
	rm -rf /cache/*
	rm -rf /dalvik-cache/*
	rm -rf /data/cache/*
	rm -rf /data/dalvik-cache/*
	rm -rf /data/anr/*
	rm -rf /data/system/dropbox/*
	rm -rf /data/vendor/dropbox/*
	rm -rf /data/misc/dropbox/*
	rm -rf /data/app/preinstall_history/*
	rm -rf /data/tombstones/*
	rm -rf /data/system/tombstones/*
	rm -rf /data/vendor/tombstones/*
	rm -rf /data/misc/tombstones/*
	rm -rf /data/system_ce/0/recent_*/*
	rm -rf /data/system/trace/*
	rm -rf /data/vendor/trace/*
	rm -rf /data/misc/trace/*
	rm -rf /data/system/stats*/*
	rm -rf /data/vendor/stats*/*
	rm -rf /data/misc/stats*/*
	rm -rf /data/system/*stats/*
	rm -rf /data/vendor/*stats/*
	rm -rf /data/misc/*stats/*
	rm -rf /data/system/bootstat/*
	rm -rf /data/system/boottrace/*
	rm -rf /data/vendor/bootstat/*
	rm -rf /data/vendor/boottrace/*
	rm -rf /data/misc/bootstat/*
	rm -rf /data/misc/boottrace/*
	rm -rf /data/system/*_log/*
	rm -rf /data/vendor/*_log/*
	rm -rf /data/misc/*_log/*
	rm -rf /data/system/*_logs/*
	rm -rf /data/vendor/*_logs/*
	rm -rf /data/misc/*_logs/*
	rm -rf /data/system/*_logger/*
	rm -rf /data/vendor/*_logger/*
	rm -rf /data/misc/*_logger/*
