set -x
[ -x "$(which magisk)" ] && MIRRORPATH=$(magisk --path)/.magisk/mirror || unset MIRRORPATH
array=$(find /system /vendor -name WCNSS_qcom_cfg.ini)
LOG=$MODPATH/common/wifi
for CFG in $array
do
[[ -f $CFG ]] && [[ ! -L $CFG ]] && {
SELECTPATH=$CFG
mkdir -p `dirname $MODPATH$CFG`
cp -af $MIRRORPATH$SELECTPATH $MODPATH$SELECTPATH
ui_print "- Wait..."
sed -i '/gEnablefwlog=/d;s/^END$/gEnablefwlog=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnablePacketLog=/d;s/^END$/gEnablePacketLog=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableApProt=/d;s/^END$/gEnableApProt=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableApOBSSProt=/d;s/^END$/gEnableApOBSSProt=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableApUapsd=/d;s/^END$/gEnableApUapsd=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/g11dSupportEnabled=/d;s/^END$/g11dSupportEnabled=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableBypass11d=/d;s/^END$/gEnableBypass11d=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnablePowerSaveOffload=/d;s/^END$/gEnablePowerSaveOffload=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/TxPower2g=/d;s/^END$/TxPower2g=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/TxPower5g=/d;s/^END$/TxPower5g=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableGreenAp=/d;s/^END$/gEnableGreenAp=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableEGAP=/d;s/^END$/gEnableEGAP=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/enable_mod_dtim_on_system_suspend=/d;s/^END$/enable_mod_dtim_on_system_suspend=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableSWLM=/d;s/^END$/gEnableSWLM=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gChannelBondingMode24GHz=/d;s/^END$/gChannelBondingMode24GHz=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gChannelBondingMode5GHz=/d;s/^END$/gChannelBondingMode5GHz=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableSARV1toSARV2=/d;s/^END$/gEnableSARV1toSARV2=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/skip_tpe_consideration=/d;s/^END$/skip_tpe_consideration=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/CcxEnabled=/d;s/^END$/CcxEnabled=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gAllowDFSChannelRoam=/d;s/^END$/gAllowDFSChannelRoam=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableNUDTracking=/d;s/^END$/gEnableNUDTracking=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableNanSupport=/d;s/^END$/gEnableNanSupport=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/genable_nan_datapath=/d;s/^END$/genable_nan_datapath=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/nan_separate_iface_support=/d;s/^END$/nan_separate_iface_support=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableTxBFin20MHz=/d;s/^END$/gEnableTxBFin20MHz=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gWmiCreditCount=/d;s/^END$/gWmiCreditCount=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gMulticastHostFwMsgs=/d;s/^END$/gMulticastHostFwMsgs=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gCountryCodePriority=/d;s/^END$/gCountryCodePriority=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableFastRoamInConcurrency=/d;s/^END$/gEnableFastRoamInConcurrency=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableDFSMasterCap=/d;s/^END$/gEnableDFSMasterCap=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/g_sta_sap_scc_on_dfs_chan=/d;s/^END$/g_sta_sap_scc_on_dfs_chan=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableVhtFor24GHzBand=/d;s/^END$/gEnableVhtFor24GHzBand=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/ImplicitQosIsEnabled=/d;s/^END$/ImplicitQosIsEnabled=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gTxBFEnable=/d;s/^END$/gTxBFEnable=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableTxSUBeamformer=/d;s/^END$/gEnableTxSUBeamformer=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/g11hSupportEnabled=/d;s/^END$/g11hSupportEnabled=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gShortGI20Mhz=/d;s/^END$/gShortGI20Mhz=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gShortGI40Mhz=/d;s/^END$/gShortGI40Mhz=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableDFSChnlScan=/d;s/^END$/gEnableDFSChnlScan=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gReorderOffloadSupported=/d;s/^END$/gReorderOffloadSupported=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableIpTcpUdpChecksumOffload=/d;s/^END$/gEnableIpTcpUdpChecksumOffload=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/active_max_channel_time_2g=/d;s/^END$/active_max_channel_time_2g=0\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableFastPath=/d;s/^END$/gEnableFastPath=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableRXLDPC=/d;s/^END$/gEnableRXLDPC=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableTXSTBC=/d;s/^END$/gEnableTXSTBC=1\nEND/g' $MODPATH$SELECTPATH
sed -i '/gEnableRXSTBC=/d;s/^END$/gEnableRXSTBC=1\nEND/g' $MODPATH$SELECTPATH
}
done
[[ -z $SELECTPATH ]] && abort "- Installation FAILED. Your device didn't support." || { mkdir -p $MODPATH/system; mv -f $MODPATH/vendor $MODPATH/system/vendor;}
