
WIFICFG="$(find /system /vendor /system_ext /product /odm /my_product -type f -name "WCNSS_qcom_cfg*.ini")"
WIFICFG2="$(find /system /vendor /system_ext /product /odm /my_product -type f -name "xtwifi.conf")"
WIFICFG3="$(find /system /vendor /system_ext /product /odm /my_product -type f -name "icm.conf")"
mkdir -p $MODPATH/tools
cp -f $MODPATH/common/addon/External-Tools/tools/$ARCH32/* $MODPATH/tools/

ui_print " "
ui_print "->[Please Wait...]<-"
ui_print " "
  for OCFG in ${WIFICFG}; do
	CFG="$MODPATH$(echo $OCFG | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG $CFG
	cp_ch -f /odm/etc/wifi/WCNSS_qcom_cfg.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg.ini
	cp_ch -f /odm/vendor/etc/wifi/WCNSS_qcom_cfg.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg.ini
	cp_ch -f /odm/etc/wifi/WCNSS_qcom_cfg_cmcc.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg_cmcc.ini
	cp_ch -f /odm/vendor/etc/wifi/WCNSS_qcom_cfg_cmcc.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg_cmcc.ini
	cp_ch -f /odm/etc/wifi/WCNSS_qcom_cfg_roam.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg_roam.ini
	cp_ch -f /odm/vendor/etc/wifi/WCNSS_qcom_cfg_roam.ini $MODPATH/system/vendor/odm/etc/wifi/WCNSS_qcom_cfg_roam.ini
	cp_ch -f /my_product/etc/wifi/WCNSS_qcom_cfg.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg.ini
	cp_ch -f /my_product/vendor/etc/wifi/WCNSS_qcom_cfg.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg.ini
	cp_ch -f /my_product/etc/wifi/WCNSS_qcom_cfg_cmcc.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg_cmcc.ini
	cp_ch -f /my_product/vendor/etc/wifi/WCNSS_qcom_cfg_cmcc.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg_cmcc.ini
	cp_ch -f /my_product/etc/wifi/WCNSS_qcom_cfg_roam.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg_roam.ini
	cp_ch -f /my_product/vendor/etc/wifi/WCNSS_qcom_cfg_roam.ini $MODPATH/system/my_product/etc/wifi/WCNSS_qcom_cfg_roam.ini
	sed -i 's/\t/  /g' $CFG
	sed -i 's/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $CFG
	sed -i '/gEnablefwlog=/d;s/^END$/gEnablefwlog=0\nEND/g' $CFG
	sed -i '/gEnablePacketLog=/d;s/^END$/gEnablePacketLog=0\nEND/g' $CFG
	sed -i '/gMulticastHostFwMsgs=/d;s/^END$/gMulticastHostFwMsgs=0\nEND/g' $CFG
	sed -i '/gEnableLogp=/d;s/^END$/gEnableLogp=0\nEND/g' $CFG
	sed -i '/gEnableApProt=/d;s/^END$/gEnableApProt=1\nEND/g' $CFG
	sed -i '/gEnableApOBSSProt=/d;s/^END$/gEnableApOBSSProt=1\nEND/g' $CFG
	sed -i '/gEnableApUapsd=/d;s/^END$/gEnableApUapsd=0\nEND/g' $CFG
	sed -i '/InfraUapsdVoSrvIntv=/d;s/^END$/InfraUapsdVoSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdViSrvIntv=/d;s/^END$/InfraUapsdViSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdBeSrvIntv=/d;s/^END$/InfraUapsdBeSrvIntv=0\nEND/g' $CFG
	sed -i '/InfraUapsdBkSrvIntv=/d;s/^END$/InfraUapsdBkSrvIntv=0\nEND/g' $CFG
	sed -i '/gEnablePowerSaveOffload=/d;s/^END$/gEnablePowerSaveOffload=0\nEND/g' $CFG
	sed -i '/gEnableTDLSWmmMode=/d;s/^END$/gEnableTDLSWmmMode=0\nEND/g' $CFG
	sed -i '/WmmIsEnabled=/d;s/^END$/WmmIsEnabled=0\nEND/g' $CFG
	sed -i '/TxPower2g=/d;s/^END$/#TxPower2g=0\nEND/g' $CFG
	sed -i '/TxPower5g=/d;s/^END$/#TxPower5g=0\nEND/g' $CFG
	sed -i '/gTxPowerCap=/d;s/^END$/#gTxPowerCap=0\nEND/g' $CFG
	sed -i '/gEnable5gEBT=/d;s/^END$/gEnable5gEBT=0\nEND/g' $CFG
	sed -i '/gEnableGreenAp=/d;s/^END$/gEnableGreenAp=0\nEND/g' $CFG
	sed -i '/gEnableEGAP=/d;s/^END$/gEnableEGAP=0\nEND/g' $CFG
	sed -i '/gEnableDFSMasterCap=/d;s/^END$/gEnableDFSMasterCap=0\nEND/g' $CFG
	sed -i '/gAllowDFSChannelRoam=/d;s/^END$/gAllowDFSChannelRoam=0\nEND/g' $CFG
	sed -i '/gDisableDFSChSwitch=/d;s/^END$/gDisableDFSChSwitch=1\nEND/g' $CFG
	sed -i '/gInitialScanNoDFSChnl=/d;s/^END$/gInitialScanNoDFSChnl=1\nEND/g' $CFG
	sed -i '/g11hSupportEnabled=/d;s/^END$/g11hSupportEnabled=0\nEND/g' $CFG
	sed -i '/gCountryCodePriority=/d;s/^END$/gCountryCodePriority=1\nEND/g' $CFG
	sed -i '/gEnableStrictRegulatoryForFCC=/d;s/^END$/gEnableStrictRegulatoryForFCC=0\nEND/g' $CFG
	sed -i '/gRegulatoryChangeCountry=/d;s/^END$/gRegulatoryChangeCountry=0\nEND/g' $CFG
	sed -i '/gEnableMuBformee=/d;s/^END$/gEnableMuBformee=1\nEND/g' $CFG
	sed -i '/gActiveMcBcBpfMode=/d;s/^END$/gActiveMcBcBpfMode=1\nEND/g' $CFG
	sed -i '/gTxBFEnable=/d;s/^END$/gTxBFEnable=1\nEND/g' $CFG
	sed -i '/gEnableTxSUBeamformer=/d;s/^END$/gEnableTxSUBeamformer=1\nEND/g' $CFG
	sed -i '/gEnableTxBFeeSAP=/d;s/^END$/gEnableTxBFeeSAP=1\nEND/g' $CFG
	sed -i '/gEnableTxBFin20MHz=/d;s/^END$/gEnableTxBFin20MHz=1\nEND/g' $CFG
	sed -i '/gShortGI20Mhz=/d;s/^END$/gShortGI20Mhz=1\nEND/g' $CFG
	sed -i '/gShortGI40Mhz=/d;s/^END$/gShortGI40Mhz=1\nEND/g' $CFG
	sed -i '/gChannelBondingMode24GHz=/d;s/^END$/gChannelBondingMode24GHz=1\nEND/g' $CFG
	sed -i '/gChannelBondingMode5GHz=/d;s/^END$/gChannelBondingMode5GHz=1\nEND/g' $CFG
	sed -i '/gEnableVhtFor24GHzBand=/d;s/^END$/gEnableVhtFor24GHzBand=1\nEND/g' $CFG
	sed -i '/gEnableVhtFor50GHzBand=/d;s/^END$/gEnableVhtFor5GHzBand=1\nEND/g' $CFG
	sed -i '/gVhtChannelWidth=/d;s/^END$/gVhtChannelWidth=2\nEND/g' $CFG
	sed -i '/BandCapability=/d;s/^END$/BandCapability=0\nEND/g' $CFG
	sed -i '/gDot11Mode=/d;s/^END$/gDot11Mode=0\nEND/g' $CFG
	sed -i '/oem_6g_support_disable=/d;s/^END$/oem_6g_support_disable=0\nEND/g' $CFG
	sed -i '/g11dSupportEnabled=/d;s/^END$/g11dSupportEnabled=0\nEND/g' $CFG
	sed -i '/gEnableBypass11d=/d;s/^END$/gEnableBypass11d=1\nEND/g' $CFG
	sed -i '/gEnableSARV1toSARV2=/d;s/^END$/#gEnableSARV1toSARV2=0\nEND/g' $CFG
	sed -i '/skip_tpe_consideration=/d;s/^END$/skip_tpe_consideration=1\nEND/g' $CFG
	sed -i '/CcxEnabled=/d;s/^END$/CcxEnabled=0\nEND/g' $CFG
	sed -i '/EseEnabled=/d;s/^END$/EseEnabled=0\nEND/g' $CFG
	sed -i '/gEnableNanSupport=/d;s/^END$/gEnableNanSupport=0\nEND/g' $CFG
	sed -i '/genable_nan_datapath=/d;s/^END$/genable_nan_datapath=0\nEND/g' $CFG
	sed -i '/nan_separate_iface_support=/d;s/^END$/nan_separate_iface_support=0\nEND/g' $CFG
	sed -i '/gWmiCreditCount=/d;s/^END$/gWmiCreditCount=0\nEND/g' $CFG
	sed -i '/ImplicitQosIsEnabled=/d;s/^END$/ImplicitQosIsEnabled=0\nEND/g' $CFG
	sed -i '/gEnableFastPath=/d;s/^END$/gEnableFastPath=1\nEND/g' $CFG
	sed -i '/gEnableTXSTBC=/d;s/^END$/gEnableTXSTBC=1\nEND/g' $CFG
	sed -i '/gEnableRXSTBC=/d;s/^END$/gEnableRXSTBC=1\nEND/g' $CFG
	sed -i '/gEnableRXLDPC=/d;s/^END$/gEnableRXLDPC=1\nEND/g' $CFG
	sed -i '/twt_responder=/d;s/^END$/twt_responder=0\nEND/g' $CFG
	sed -i '/gGO11ACOverride=/d;s/^END$/gGO11ACOverride=1\nEND/g' $CFG
	sed -i '/enable_vhtmcs_10_11_support=/d;s/^END$/enable_vhtmcs_10_11_support=0\nEND/g' $CFG
	sed -i '/gForce1x1Exception=/d;s/^END$/gForce1x1Exception=0\nEND/g' $CFG
	sed -i '/roam_bad_rssi_thresh_offset_2g=/d;s/^END$/#roam_bad_rssi_thresh_offset_2g=0\nEND/g' $CFG
	sed -i '/roam_bg_scan_bad_rssi_thresh=/d;s/^END$/#roam_bg_scan_bad_rssi_thresh=0\nEND/g' $CFG
	sed -i '/groam_dense_rssi_thresh_offset=/d;s/^END$/#groam_dense_rssi_thresh_offset=0\nEND/g' $CFG
	sed -i '/roam_data_rssi_threshold_triggers=/d;s/^END$/roam_data_rssi_threshold_triggers=0\nEND/g' $CFG
	sed -i '/idle_roam_min_rssi=/d;s/^END$/#idle_roam_min_rssiidle_roam_min_rssi=0\nEND/g' $CFG
	sed -i '/enable_idle_roam=/d;s/^END$/enable_idle_roam=false\nEND/g' $CFG
	sed -i '/ssdp=/d;s/^END$/ssdp=0\nEND/g' $CFG
	sed -i '/RoamRssiDiff=/d;s/^END$/RoamRssiDiff=5\nEND/g' $CFG
	sed -i '/gEnableMCCMode=/d;s/^END$/gEnableMCCMode=1\nEND/g' $CFG
	sed -i '/gWlanMccToSccSwitchMode/d;s/^END$/gWlanMccToSccSwitchMode=4\nEND/g' $CFG
	sed -i '/FastRoamEnabled=/d;s/^END$/FastRoamEnabled=0\nEND/g' $CFG
	sed -i '/gEnableSNRMonitoring=/d;s/^END$/gEnableSNRMonitoring=0\nEND/g' $CFG
	sed -i '/gEnableTDLSSupport=/d;s/^END$/#gEnableTDLSSupport=0\nEND/g' $CFG
	sed -i '/gEnableTDLSImplicitTrigger=/d;s/^END$/#gEnableTDLSImplicitTrigger=0\nEND/g' $CFG
	sed -i '/gRrmEnable=/d;s/^END$/gRrmEnable=1\nEND/g' $CFG
	sed -i '/gEnableRxThread=/d;s/^END$/gEnableRxThread=1\nEND/g' $CFG
	sed -i '/FastTransitionEnabled=/d;s/^END$/FastTransitionEnabled=1\nEND/g' $CFG
	sed -i '/gMaxConcurrentActiveSessions=/d;s/^END$/gMaxConcurrentActiveSessions=4\nEND/g' $CFG
	sed -i '/GROEnable=/d;s/^END$/GROEnable=3\nEND/g' $CFG
	sed -i '/legacy_mode_csum_disable=/d;s/^END$/legacy_mode_csum_disable=1\nEND/g' $CFG
	sed -i '/adaptive_dwell_mode_enabled=/d;s/^END$/adaptive_dwell_mode_enabled=1\nEND/g' $CFG
	sed -i '/hostscan_adaptive_dwell_mode=/d;s/^END$/hostscan_adaptive_dwell_mode=1\nEND/g' $CFG
	sed -i '/enable_bus_suspend_in_go_mode=/d;s/^END$/enable_bus_suspend_in_go_mode=1\nEND/g' $CFG
	sed -i '/gEnableNUDTracking=/d;s/^END$/gEnableNUDTracking=0\nEND/g' $CFG
	sed -i '/wow_check_rx_pending_enable=/d;s/^END$/wow_check_rx_pending_enable=1\nEND/g' $CFG
	sed -i '/enable_bus_suspend_in_sap_mode=/d;s/^END$/enable_bus_suspend_in_sap_mode=1\nEND/g' $CFG
	sed -i '/gEnableModulatedDTIM=/d;s/^END$/gEnableModulatedDTIM=3\nEND/g' $CFG
	sed -i '/gMaxLIModulatedDTIM=/d;s/^END$/gMaxLIModulatedDTIM=3\nEND/g' $CFG
	sed -i '/enable_mod_dtim_on_system_suspend=/d;s/^END$/enable_mod_dtim_on_system_suspend=1\nEND/g' $CFG
	sed -i '/^ *#/d; /^ *$/d' $CFG
	done

  for OCFG2 in ${WIFICFG2}; do
	CFG2="$MODPATH$(echo $OCFG2 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG2 $CFG2
	sed -i 's/\t/  /g' $CFG2
	sed -i 's/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 1/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 2/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 3/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 4/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = 5/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i 's/DEBUG_GLOBAL_LOG_LEVEL = ALL/DEBUG_GLOBAL_LOG_LEVEL = 0/g' $CFG2
	sed -i '/^ *#/d; /^ *$/d' $CFG2
	done

  for OCFG3 in ${WIFICFG3}; do
	CFG3="$MODPATH$(echo $OCFG3 | sed "s|^/vendor|/system/vendor|g" | sed "s|^/system_ext|/system/system_ext|g" | sed "s|^/product|/system/product|g" | sed "s|^/my_product|/system/my_product|g" | sed "s|^/odm|/system/vendor/odm|g")"
	cp_ch $ORIGDIR$OCFG3 $CFG3
	sed -i 's/\t/  /g' $CFG3
	sed -i 's/<!--.*-->//; /<!--/,/-->/d; /^ *#/d; /^ *$/d' $CFG3
	sed -i 's/debug_level=1/debug_level=0/g' $CFG3
	sed -i 's/debug_level=2/debug_level=0/g' $CFG3
	sed -i 's/debug_level=3/debug_level=0/g' $CFG3
	sed -i 's/debug_level=4/debug_level=0/g' $CFG3
	sed -i 's/debug_level=5/debug_level=0/g' $CFG3
	sed -i '/^ *#/d; /^ *$/d' $CFG3
	done
